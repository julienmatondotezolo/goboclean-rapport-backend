#!/bin/bash
SUPABASE_URL="https://ihlnwzrsvfxgossytuiz.supabase.co"
ANON_KEY="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlobG53enJzdmZ4Z29zc3l0dWl6Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzAxMzgwMDgsImV4cCI6MjA4NTcxNDAwOH0.3agrqDXOPnBiHMHxm80nlf7F5qyswYaNGvMwxDkmZz8"
API="http://localhost:3001"

get_token() {
  curl -s -X POST "$SUPABASE_URL/auth/v1/token?grant_type=password" \
    -H "apikey: $ANON_KEY" -H "Content-Type: application/json" \
    -d "{\"email\":\"$1\",\"password\":\"$2\"}" | python3 -c "import json,sys; print(json.load(sys.stdin)['access_token'])"
}

ADMIN_TOKEN=$(get_token "admin@goboclean.be" "GoBo2026!Admin")
WORKER_TOKEN=$(get_token "worker@goboclean.be" "GoBo2026!Worker")

MISSION_ID="84ff01c6-65bd-439c-aecd-a9c5b5b278e8"

echo "=== 1. Worker lists missions ==="
curl -s "$API/missions" -H "Authorization: Bearer $WORKER_TOKEN"
echo ""

echo "=== 2. Worker starts mission ==="
curl -s -X POST "$API/missions/$MISSION_ID/start" -H "Authorization: Bearer $WORKER_TOKEN"
echo ""

echo "=== 3. Check notifications ==="
curl -s "$API/notifications" -H "Authorization: Bearer $WORKER_TOKEN"
echo ""

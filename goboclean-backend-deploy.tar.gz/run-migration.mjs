import { createClient } from '@supabase/supabase-js';
import { readFileSync } from 'fs';

const supabase = createClient(
  'https://ihlnwzrsvfxgossytuiz.supabase.co',
  'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImlobG53enJzdmZ4Z29zc3l0dWl6Iiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3MDEzODAwOCwiZXhwIjoyMDg1NzE0MDA4fQ.-Zeg8QUFngz58l9BG6b9Y13LiPYUeJBTCKMtszdomNs'
);

// Check if tables exist
const { data: tables, error: tablesErr } = await supabase
  .from('missions')
  .select('id')
  .limit(1);

if (tablesErr && tablesErr.message.includes('does not exist')) {
  console.log('missions table does not exist yet - migration needed');
} else if (!tablesErr) {
  console.log('missions table already exists!');
} else {
  console.log('Error checking:', tablesErr.message);
}
